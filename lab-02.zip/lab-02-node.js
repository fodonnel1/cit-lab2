// adding a comment

//Second comment
console.log("Hello World");

console.log(`Square of 20 is ${square(10)}`);